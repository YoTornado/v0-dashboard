import type React from "react"
import { type ChatMessage, MessageSource } from "../types"

interface ChatBubbleProps {
  message: ChatMessage
}

export const ChatBubble: React.FC<ChatBubbleProps> = ({ message }) => {
  const isTutor = message.source === MessageSource.GEMINI
  const isSystem = message.source === MessageSource.SYSTEM

  const bubbleClasses = isTutor
    ? "bg-purple-100 border border-purple-200 text-gray-800 self-start"
    : isSystem
      ? "bg-yellow-50 border border-yellow-200 text-yellow-800 self-center text-sm"
      : "bg-blue-100 border border-blue-200 text-gray-800 self-end"

  const authorClasses = isTutor ? "font-bold text-purple-700" : isSystem ? "hidden" : "font-bold text-blue-700"

  return (
    <div className={`w-fit max-w-lg rounded-xl px-4 py-3 shadow-sm font-inter ${bubbleClasses}`}>
      <p className={authorClasses}>{message.source}</p>
      <p className="text-gray-800 whitespace-pre-wrap font-medium">{message.text}</p>
      <p className="text-xs text-gray-500 mt-2 text-right">{message.timestamp}</p>
    </div>
  )
}
