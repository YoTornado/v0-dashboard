"use client"

import { Video, Clock, Users, Calculator, Atom, Beaker, Dna, Code, Plus } from "lucide-react"
import { Button } from "./ui/button"
import { Card } from "./ui/card"
import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"

export function MainDashboard() {
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null)
  const [clickedSubject, setClickedSubject] = useState<string | null>(null)
  const [typewriterText, setTypewriterText] = useState("")
  const [typewriterIndex, setTypewriterIndex] = useState(0)
  const router = useRouter()

  const subjects = [
    {
      id: "mathematics",
      name: "Mathematics",
      icon: Calculator,
      color: "bg-gradient-to-br from-[#F2EBFB] to-[#E8D5F7] text-[#9667E0]",
      bgColor: "bg-gradient-to-br from-[#FBFAFF] to-[#F8F4FF]",
      borderColor: "border-[#EBD9FC]",
      hoverColor: "hover:from-[#F8F4FF] hover:to-[#F2EBFB]",
    },
    {
      id: "physics",
      name: "Physics",
      icon: Atom,
      color: "bg-gradient-to-br from-[#F2EBFB] to-[#E8D5F7] text-[#9667E0]",
      bgColor: "bg-gradient-to-br from-[#FBFAFF] to-[#F8F4FF]",
      borderColor: "border-[#EBD9FC]",
      hoverColor: "hover:from-[#F8F4FF] hover:to-[#F2EBFB]",
    },
    {
      id: "chemistry",
      name: "Chemistry",
      icon: Beaker,
      color: "bg-gradient-to-br from-[#F2EBFB] to-[#E8D5F7] text-[#9667E0]",
      bgColor: "bg-gradient-to-br from-[#FBFAFF] to-[#F8F4FF]",
      borderColor: "border-[#EBD9FC]",
      hoverColor: "hover:from-[#F8F4FF] hover:to-[#F2EBFB]",
    },
    {
      id: "biology",
      name: "Biology",
      icon: Dna,
      color: "bg-gradient-to-br from-[#F2EBFB] to-[#E8D5F7] text-[#9667E0]",
      bgColor: "bg-gradient-to-br from-[#FBFAFF] to-[#F8F4FF]",
      borderColor: "border-[#EBD9FC]",
      hoverColor: "hover:from-[#F8F4FF] hover:to-[#F2EBFB]",
    },
    {
      id: "computer-science",
      name: "Computer Science",
      icon: Code,
      color: "bg-gradient-to-br from-[#F2EBFB] to-[#E8D5F7] text-[#9667E0]",
      bgColor: "bg-gradient-to-br from-[#FBFAFF] to-[#F8F4FF]",
      borderColor: "border-[#EBD9FC]",
      hoverColor: "hover:from-[#F8F4FF] hover:to-[#F2EBFB]",
    },
    {
      id: "custom-tutor",
      name: "Create Custom Tutor",
      icon: Plus,
      color: "bg-gradient-to-br from-[#F2EBFB] to-[#E8D5F7] text-[#9667E0]",
      bgColor: "bg-gradient-to-br from-[#FBFAFF] to-[#F8F4FF]",
      borderColor: "border-[#EBD9FC]",
      hoverColor: "hover:from-[#F8F4FF] hover:to-[#F2EBFB]",
      isNew: true,
    },
  ]

  const pastSessions = [
    { subject: "Mathematics", date: "Yesterday", duration: "45 min", students: 12, subjectData: subjects[0] },
    { subject: "Physics", date: "2 days ago", duration: "60 min", students: 8, subjectData: subjects[1] },
    { subject: "Chemistry", date: "3 days ago", duration: "30 min", students: 15, subjectData: subjects[2] },
  ]

  const typewriterPhrases = [
    "your tutoring adventure",
    "learning something new",
    "an amazing session",
    "your educational journey",
    "mastering new concepts",
  ]

  useEffect(() => {
    let currentPhraseIndex = 0
    let currentCharIndex = 0
    let isDeleting = false
    let timeoutId: NodeJS.Timeout

    const typeWriter = () => {
      const currentPhrase = typewriterPhrases[currentPhraseIndex]

      if (!isDeleting) {
        setTypewriterText(currentPhrase.substring(0, currentCharIndex + 1))
        currentCharIndex++

        if (currentCharIndex === currentPhrase.length) {
          timeoutId = setTimeout(() => {
            isDeleting = true
            typeWriter()
          }, 2000)
          return
        }
      } else {
        setTypewriterText(currentPhrase.substring(0, currentCharIndex - 1))
        currentCharIndex--

        if (currentCharIndex === 0) {
          isDeleting = false
          currentPhraseIndex = (currentPhraseIndex + 1) % typewriterPhrases.length
        }
      }

      const typingSpeed = isDeleting ? 50 : 100
      timeoutId = setTimeout(typeWriter, typingSpeed)
    }

    typeWriter()

    return () => {
      if (timeoutId) clearTimeout(timeoutId)
    }
  }, [])

  const handleSubjectClick = (subjectId: string) => {
    setSelectedSubject(subjectId)
    setClickedSubject(subjectId)

    setTimeout(() => {
      setClickedSubject(null)
    }, 200)
  }

  const handleStartSession = () => {
    if (selectedSubject) {
      localStorage.setItem("selectedSubject", selectedSubject)
      router.push("/session")
    }
  }

  return (
    <div className="h-full flex-1 p-8 overflow-auto">
      <div className="h-full flex flex-col max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-12 welcome-container">
          <h1 className="welcome-title font-inter text-4xl font-bold mb-3 tracking-tight leading-tight">
            Welcome back, John
          </h1>
          <p className="welcome-subtitle font-inter text-xl font-medium text-gray-600 leading-relaxed">
            Ready to start your next tutoring session?
          </p>
        </div>

        {/* Join Session Section - Updated with glassmorphism */}
        <div className="mb-12">
          <Card className="p-8 border-2 bg-white/30 backdrop-blur-lg shadow-xl border-[#EBD9FC] transition-all duration-300">
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-[#9667E0] to-[#D4BFFC] rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
                <Video className="w-10 h-10 text-white" />
              </div>
              <h2 className="font-inter text-3xl font-bold text-gray-900 mb-3 tracking-tight">Start a New Session</h2>
              <p className="font-inter text-lg font-medium text-gray-600 mb-8">
                Choose a subject and begin <span className="typewriter-text">{typewriterText}</span>
                <span className="typewriter-cursor">|</span>
              </p>

              {/* Subject Cards Grid - Updated with subtle glassmorphism */}
              <div className="grid grid-cols-3 gap-4 max-w-2xl mx-auto mb-8">
                {subjects.map((subject) => {
                  const Icon = subject.icon
                  const isSelected = selectedSubject === subject.id
                  const isClicked = clickedSubject === subject.id
                  return (
                    <button
                      key={subject.id}
                      onClick={() => handleSubjectClick(subject.id)}
                      className={`p-5 rounded-xl border-2 transition-all duration-200 group relative backdrop-blur-sm ${
                        isSelected
                          ? `border-[#9667E0] bg-white/70 shadow-lg ring-2 ring-[#D4BFFC]`
                          : `border-gray-200/70 hover:border-[#D4BFFC] bg-white/40 hover:bg-white/60 hover:shadow-sm`
                      } ${isClicked ? "animate-pulse" : ""}`}
                    >
                      {subject.isNew && (
                        <div className="absolute top-3 right-3 bg-[#9667E0] text-white text-xs px-2 py-1 font-medium shadow-sm rounded-sm">
                          New
                        </div>
                      )}
                      <div
                        className={`w-14 h-14 rounded-xl flex items-center justify-center mx-auto mb-3 transition-all duration-300 ${
                          isSelected ? `${subject.color} shadow-md` : subject.color
                        }`}
                      >
                        <Icon className={`w-7 h-7 transition-all duration-200 ${isSelected ? "animate-pulse" : ""}`} />
                      </div>
                      <p
                        className={`font-inter text-sm font-semibold transition-all duration-200 ${
                          isSelected ? "text-[#9667E0]" : "text-gray-900"
                        }`}
                      >
                        {subject.name}
                      </p>
                    </button>
                  )
                })}
              </div>

              {/* Enhanced CTA Button - Updated with navigation functionality */}
              <Button
                onClick={handleStartSession}
                className={`px-12 text-lg shadow-lg transition-all duration-300 py-6 border-0 rounded-2xl font-inter font-semibold ${
                  selectedSubject
                    ? "bg-[#9667E0] hover:bg-[#8055D1] text-white border-0 pulse-button"
                    : "bg-gray-400 cursor-not-allowed text-white"
                }`}
                disabled={!selectedSubject}
              >
                <Video className="w-5 h-5 mr-3" />
                Start Session Now
              </Button>
            </div>
          </Card>
        </div>

        {/* Past Sessions - Updated with glassmorphism */}
        <div className="flex-1">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-inter text-2xl font-bold text-gray-900 tracking-tight">Past Sessions</h3>
            <Button
              variant="ghost"
              size="sm"
              className="font-inter font-medium text-[#9667E0] hover:text-[#8055D1] hover:bg-white/30 backdrop-blur-sm rounded-lg"
            >
              View All
            </Button>
          </div>

          <div className="space-y-4">
            {pastSessions.map((session, index) => {
              const Icon = session.subjectData.icon
              return (
                <div
                  key={index}
                  className="flex items-center justify-between p-5 rounded-xl border-2 border-[#EBD9FC] bg-white/30 backdrop-blur-sm hover:bg-white/50 hover:shadow-md transition-all duration-200 group"
                >
                  <div className="flex items-center space-x-4">
                    <div
                      className={`w-14 h-14 rounded-xl flex items-center justify-center transition-all duration-200 ${session.subjectData.color}`}
                    >
                      <Icon className="w-7 h-7" />
                    </div>
                    <div>
                      <div className="flex items-center space-x-3 mb-1">
                        <p className="font-inter text-lg font-semibold text-gray-900">{session.subject}</p>
                        <span
                          className={`px-2 py-1 text-xs font-medium rounded-full bg-white/50 backdrop-blur-sm border border-[#EBD9FC]/50 text-[#9667E0]`}
                        >
                          {session.subject}
                        </span>
                      </div>
                      <div className="flex items-center space-x-6 text-gray-600">
                        <span className="flex items-center">
                          <Clock className="w-4 h-4 mr-2 text-[#9667E0]" />
                          <span className="font-inter text-sm font-medium">{session.date}</span>
                        </span>
                        <span className="flex items-center">
                          <Users className="w-4 h-4 mr-2 text-[#9667E0]" />
                          <span className="font-inter text-sm font-medium">{session.students} students</span>
                        </span>
                        <span className="font-inter text-sm font-medium text-gray-500">{session.duration}</span>
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="font-inter font-medium text-[#9667E0] hover:text-[#8055D1] hover:bg-white/40 backdrop-blur-sm rounded-lg"
                  >
                    View Details
                  </Button>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}
