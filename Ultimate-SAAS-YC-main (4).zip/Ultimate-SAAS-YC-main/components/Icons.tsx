import type React from "react"

interface IconProps {
  className?: string
}

export const MicIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path d="M12 2a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Zm0 12.5a3.5 3.5 0 0 1-3.5-3.5V5a3.5 3.5 0 0 1 7 0v6a3.5 3.5 0 0 1-3.5 3.5Z" />
    <path d="M12 15c-2.49 0-4.5 2.01-4.5 4.5v1h9v-1c0-2.49-2.01-4.5-4.5-4.5Z" />
  </svg>
)

export const MicOffIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path d="m12 15c-2.49 0-4.5 2.01-4.5 4.5v1h9v-1c0-2.49-2.01-4.5-4.5-4.5zm-5.021-9.979.707-.707L19.25 15.879l-.707.707-1.562-1.562a3.486 3.486 0 0 1-4.46.002L9.5 12.5V11h-2V5a3 3 0 0 1 .55-1.72zM12 2a3 3 0 0 0-3 3v.36l6.14 6.14a3.5 3.5 0 0 0 .36-3V5a3 3 0 0 0-3-3z" />
  </svg>
)

export const ScreenShareIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path d="M20 18c1.1 0 1.99-.9 1.99-2L22 6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2H0v2h24v-2h-4zM4 16V6h16v10H4z" />
  </svg>
)

export const StopScreenShareIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path d="M21.22 18.02 2.51 3.31 1.45 4.37 3.12 6.04H2c-1.1 0-2 .9-2 2v8c0 1.1.9 2 2 2H0v2h17.12l3.43 3.43 1.06-1.06-.39-.38ZM4 16V8.12l7.88 7.88H4Zm17.99-10.03L22 6c0-1.1-.9-2-2-2H6.12l2 2H20v8.12l1.62 1.62c.24-.32.38-.7.38-1.11V6.01c0-.01 0-.01 0-.02Z" />
  </svg>
)
