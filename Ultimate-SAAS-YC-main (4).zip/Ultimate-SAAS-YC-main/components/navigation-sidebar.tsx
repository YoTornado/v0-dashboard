"use client"

import { Home, BookOpen, Calendar, Settings, Users, Video, Bell, Globe, HelpCircle } from "lucide-react"
import { useState } from "react"

export function NavigationSidebar() {
  const [hoveredItem, setHoveredItem] = useState<string | null>(null)

  const navItems = [
    { icon: Home, label: "Dashboard", active: true },
    { icon: Video, label: "Join Session" },
    { icon: BookOpen, label: "Subjects" },
    { icon: Calendar, label: "Schedule" },
    { icon: Users, label: "Students" },
    { icon: Settings, label: "Settings" },
  ]

  // Reordered utility items: Help (top), Language (middle), Notification (bottom)
  const utilityItems = [
    { icon: HelpCircle, label: "Help" },
    { icon: Globe, label: "Language" },
    { icon: Bell, label: "Notifications" },
  ]

  // Level progress component - Updated with purple theme and animation
  const LevelProgress = () => {
    const currentLevel = 3
    const progress = 65 // percentage to next level
    const radius = 20
    const strokeWidth = 3
    const normalizedRadius = radius - strokeWidth * 2
    const circumference = normalizedRadius * 2 * Math.PI
    const strokeDasharray = `${circumference} ${circumference}`
    const strokeDashoffset = circumference - (progress / 100) * circumference

    return (
      <div className="w-full flex justify-center mb-6">
        <div className="relative flex items-center justify-center w-12 h-12">
          {/* Background circle */}
          <svg className="absolute w-12 h-12 progress-container">
            <circle
              stroke="#F2EBFB"
              fill="transparent"
              strokeWidth={strokeWidth}
              r={normalizedRadius}
              cx="24"
              cy="24"
            />
            {/* Progress circle - Added animation class */}
            <circle
              stroke="#9667E0"
              fill="transparent"
              strokeWidth={strokeWidth}
              strokeDasharray={strokeDasharray}
              style={{ strokeDashoffset }}
              strokeLinecap="round"
              r={normalizedRadius}
              cx="24"
              cy="24"
              className="progress-circle transition-all duration-300"
            />
          </svg>
          {/* Level number - Perfectly centered */}
          <div className="relative z-10 flex items-center justify-center">
            <span className="text-sm text-gray-700 leading-none font-semibold">{currentLevel}</span>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-white/30 backdrop-blur-sm h-full w-24 rounded-2xl shadow-lg border-2 border-[#EBD9FC] flex-shrink-0 relative">
      <div className="flex flex-col items-center py-6 h-full">
        {/* Logo */}
        <div className="mb-4">
          <div className="w-12 h-12 bg-gradient-to-br from-[#9667E0] to-[#D4BFFC] rounded-xl flex items-center justify-center shadow-md">
            <BookOpen className="w-7 h-7 text-white" />
          </div>
        </div>

        {/* Level Progress - Now properly centered with animation */}
        <LevelProgress />

        {/* Navigation Items - Updated with purple theme */}
        <nav className="flex flex-col space-y-4 flex-1 justify-center mt-4">
          {navItems.map((item, index) => {
            const Icon = item.icon
            return (
              <div key={index} className="relative">
                <button
                  className={`p-4 rounded-xl transition-all duration-300 group relative ${
                    item.active
                      ? "bg-[#F2EBFB] text-[#9667E0] shadow-md border border-[#EBD9FC]"
                      : "hover:bg-[#FBFAFF] text-gray-600 hover:text-[#9667E0]"
                  }`}
                  onMouseEnter={() => setHoveredItem(item.label)}
                  onMouseLeave={() => setHoveredItem(null)}
                >
                  <Icon className="w-6 h-6" />
                </button>

                {/* Tooltip */}
                {hoveredItem === item.label && (
                  <div className="absolute left-full ml-3 top-1/2 transform -translate-y-1/2 bg-[#9667E0] text-white text-sm px-3 py-2 rounded-lg shadow-lg z-50 whitespace-nowrap opacity-0 animate-in fade-in duration-200">
                    {item.label}
                    <div className="absolute right-full top-1/2 transform -translate-y-1/2 border-4 border-transparent border-r-[#9667E0]" />
                  </div>
                )}
              </div>
            )
          })}
        </nav>

        {/* Utility Icons - Updated with purple theme */}
        <div className="mb-4">
          <div className="flex flex-col space-y-2">
            {utilityItems.map((item, index) => {
              const Icon = item.icon
              return (
                <div key={index} className="relative">
                  <button
                    className="p-2 rounded-lg text-gray-500 hover:text-[#9667E0] hover:bg-[#FBFAFF] transition-all duration-200 group"
                    onMouseEnter={() => setHoveredItem(item.label)}
                    onMouseLeave={() => setHoveredItem(null)}
                  >
                    <Icon className="w-4 h-4" />
                  </button>

                  {/* Tooltip */}
                  {hoveredItem === item.label && (
                    <div className="absolute left-full ml-3 top-1/2 transform -translate-y-1/2 bg-[#9667E0] text-white text-sm px-3 py-2 rounded-lg shadow-lg z-50 whitespace-nowrap opacity-0 animate-in fade-in duration-200">
                      {item.label}
                      <div className="absolute right-full top-1/2 transform -translate-y-1/2 border-4 border-transparent border-r-[#9667E0]" />
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </div>

        {/* User Avatar */}
        <div className="mt-auto">
          <div className="w-12 h-12 bg-gradient-to-br from-[#D4BFFC] to-[#EBD9FC] rounded-full flex items-center justify-center shadow-md hover:shadow-lg transition-all duration-200">
            <span className="text-[#9667E0]">JD</span>
          </div>
        </div>
      </div>
    </div>
  )
}
