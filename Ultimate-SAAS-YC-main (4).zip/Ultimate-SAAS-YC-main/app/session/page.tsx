"use client"

import type React from "react"
import { useRef, useEffect, useState } from "react"
import { useTutorSession } from "../../hooks/useTutorSession"
import { ChatBubble } from "../../components/ChatBubble"
import { MicIcon, ScreenShareIcon, StopScreenShareIcon } from "../../components/Icons"
import type { ConnectionStatus } from "../../types"
import { ArrowLeft, Mic, MicOff, Volume2, VolumeX, Upload, MoreHorizontal, User } from "lucide-react"
import Link from "next/link"

const TutoringSessionPage: React.FC = () => {
  const videoElementRef = useRef<HTMLVideoElement>(null)
  const chatLogRef = useRef<HTMLDivElement>(null)
  const { messages, isSessionActive, connectionStatus, startSession, stopSession } = useTutorSession(videoElementRef)
  const [isMuted, setIsMuted] = useState(false)
  const [isAudioEnabled, setIsAudioEnabled] = useState(true)

  const [selectedSubject, setSelectedSubject] = useState<string>("Mathematics")

  useEffect(() => {
    const subject = localStorage.getItem("selectedSubject") || "Mathematics"
    setSelectedSubject(subject.charAt(0).toUpperCase() + subject.slice(1).replace("-", " "))
  }, [])

  useEffect(() => {
    if (chatLogRef.current) {
      chatLogRef.current.scrollTop = chatLogRef.current.scrollHeight
    }
  }, [messages])

  const getStatusIndicator = (status: ConnectionStatus) => {
    switch (status) {
      case "connected":
        return (
          <div className="flex items-center">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
            </span>
            <span className="ml-2 text-green-400 font-inter font-medium">Live</span>
          </div>
        )
      case "connecting":
        return (
          <div className="flex items-center">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-yellow-500"></span>
            </span>
            <span className="ml-2 text-yellow-400 font-inter font-medium">Connecting...</span>
          </div>
        )
      case "error":
        return (
          <div className="flex items-center">
            <span className="relative flex h-3 w-3">
              <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
            </span>
            <span className="ml-2 text-red-400 font-inter font-medium">Error</span>
          </div>
        )
      default:
        return (
          <div className="flex items-center">
            <span className="relative flex h-3 w-3">
              <span className="relative inline-flex rounded-full h-3 w-3 bg-gray-500"></span>
            </span>
            <span className="ml-2 text-gray-400 font-inter font-medium">Offline</span>
          </div>
        )
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 font-inter">
      <header className="bg-gray-900/80 backdrop-blur-lg border-b border-purple-500/20 px-6 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 text-white/80 hover:text-white transition-colors">
            <ArrowLeft className="w-5 h-5" />
            <span className="font-medium">Back to Dashboard</span>
          </Link>

          <div className="text-center">
            <h1 className="text-2xl font-bold text-white tracking-tight">AI Tutor Session</h1>
            <p className="text-purple-300 text-sm font-medium">{selectedSubject} • Personal AI Assistant</p>
          </div>

          <div className="flex items-center gap-4">{getStatusIndicator(connectionStatus)}</div>
        </div>
      </header>

      <div className="flex h-[calc(100vh-200px)]">
        {/* Left Column: User Screenshare */}
        <div className="w-3/5 p-6 flex flex-col">
          <div className="flex-1 flex flex-col">
            {/* Video Container */}
            <div className="flex-1 bg-gray-900/70 rounded-xl border border-purple-500/10 relative overflow-hidden">
              <video ref={videoElementRef} autoPlay playsInline muted className="w-full h-full object-contain" />

              {/* AI Tutor Avatar Box - positioned in upper area like the image */}
              <div className="absolute top-6 right-6 w-96 h-56 bg-white backdrop-blur-sm rounded-xl border border-gray-200/50 flex flex-col items-center justify-center shadow-2xl z-20">
                <div className="w-20 h-20 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center mb-4">
                  <User className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-gray-800 font-bold text-xl font-inter">AI TUTOR AVATAR</h3>
                <p className="text-gray-600 text-sm font-medium mt-2">Ready to assist you</p>
              </div>

              {!isSessionActive && (
                <div className="absolute inset-0 bg-gray-900/80 flex flex-col items-center justify-center">
                  <ScreenShareIcon className="w-20 h-20 text-purple-400 mb-4" />
                  <p className="text-purple-200 text-lg font-medium mb-2">Screen share will appear here</p>
                  <p className="text-purple-300/70 text-sm">Click "Start Session" to begin</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Conversation Area */}
        <div className="w-2/5 p-6 flex flex-col">
          <div className="bg-gray-100/95 backdrop-blur-lg border border-gray-200/50 rounded-2xl p-6 flex-1 flex flex-col">
            <h2 className="text-gray-800 font-bold text-xl font-inter mb-4 border-b border-gray-300/50 pb-3">
              Conversation area
            </h2>

            <div ref={chatLogRef} className="flex-1 overflow-y-auto pr-2 space-y-4">
              {messages.map((msg) => (
                <ChatBubble key={msg.id} message={msg} />
              ))}

              {isSessionActive && messages.length === 1 && (
                <div className="flex flex-col items-center text-center p-6 text-gray-600">
                  <MicIcon className="w-12 h-12 mb-3 text-purple-500" />
                  <p className="font-semibold text-gray-800">Listening...</p>
                  <p className="text-sm text-gray-600">The tutor is ready. Start speaking to interact.</p>
                </div>
              )}

              {messages.length === 0 && (
                <div className="flex flex-col items-center text-center p-6 text-gray-600">
                  <div className="w-12 h-12 mb-3 rounded-full bg-purple-100 flex items-center justify-center">
                    <MicIcon className="w-6 h-6 text-purple-500" />
                  </div>
                  <p className="font-semibold text-gray-800">Ready to Start</p>
                  <p className="text-sm text-gray-600">Click "Start Session" to begin your tutoring session</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="fixed bottom-8 left-1/2 transform -translate-x-1/2">
        <div className="bg-gray-900/90 backdrop-blur-lg border border-purple-500/20 rounded-2xl px-6 py-4 flex items-center gap-4 shadow-2xl">
          {/* Start/Stop Session Button */}
          <button
            onClick={isSessionActive ? stopSession : startSession}
            disabled={connectionStatus === "connecting"}
            className={`w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 shadow-lg ${
              isSessionActive
                ? "bg-red-500 hover:bg-red-600 text-white"
                : "bg-purple-600 hover:bg-purple-700 text-white"
            } ${connectionStatus === "connecting" ? "opacity-50 cursor-not-allowed" : ""}`}
          >
            {isSessionActive ? <StopScreenShareIcon className="w-6 h-6" /> : <ScreenShareIcon className="w-6 h-6" />}
          </button>

          {/* Upload Button */}
          <button className="w-12 h-12 rounded-full bg-gray-700 hover:bg-gray-600 text-white flex items-center justify-center transition-all duration-300">
            <Upload className="w-5 h-5" />
          </button>

          {/* Microphone Toggle */}
          <button
            onClick={() => setIsMuted(!isMuted)}
            className={`w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 ${
              isMuted ? "bg-red-500 hover:bg-red-600" : "bg-gray-700 hover:bg-gray-600"
            } text-white`}
          >
            {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {/* Audio Toggle */}
          <button
            onClick={() => setIsAudioEnabled(!isAudioEnabled)}
            className={`w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 ${
              !isAudioEnabled ? "bg-red-500 hover:bg-red-600" : "bg-gray-700 hover:bg-gray-600"
            } text-white`}
          >
            {isAudioEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
          </button>

          {/* More Options */}
          <button className="w-12 h-12 rounded-full bg-gray-700 hover:bg-gray-600 text-white flex items-center justify-center transition-all duration-300">
            <MoreHorizontal className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  )
}

export default TutoringSessionPage
