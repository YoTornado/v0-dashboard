import { NavigationSidebar } from "@/components/navigation-sidebar"
import { MainDashboard } from "@/components/main-dashboard"

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FBFAFF] via-[#F8F6FF] to-[#F2EBFB] p-4 relative overflow-hidden">
      {/* Enhanced floating background elements */}
      <div className="absolute inset-0 pointer-events-none z-0">
        {/* Primary floating elements */}
        <div className="floating-element-1 absolute top-10 left-10 w-40 h-40 bg-gradient-to-br from-[#9667E0]/28 to-[#D4BFFC]/18 rounded-full blur-xl"></div>
        <div className="floating-element-2 absolute top-40 right-20 w-30 h-30 bg-gradient-to-br from-[#D4BFFC]/32 to-[#9667E0]/22 rounded-full blur-lg"></div>
        <div className="floating-element-3 absolute bottom-32 left-32 w-50 h-50 bg-gradient-to-br from-[#9667E0]/22 to-[#D4BFFC]/28 rounded-full blur-2xl"></div>
        <div className="floating-element-4 absolute bottom-20 right-40 w-36 h-36 bg-gradient-to-br from-[#D4BFFC]/37 to-[#9667E0]/27 rounded-full blur-xl"></div>
        <div className="floating-element-5 absolute top-1/2 left-1/4 w-26 h-26 bg-gradient-to-br from-[#9667E0]/32 to-[#D4BFFC]/22 rounded-full blur-lg"></div>
        <div className="floating-element-6 absolute top-1/3 right-1/3 w-44 h-44 bg-gradient-to-br from-[#D4BFFC]/25 to-[#9667E0]/20 rounded-full blur-2xl"></div>
        
        {/* Additional smaller floating elements for more depth */}
        <div className="floating-element-1 absolute top-20 right-10 w-20 h-20 bg-gradient-to-br from-[#9667E0]/37 to-transparent rounded-full blur-md opacity-65" style={{ animationDelay: '1s' }}></div>
        <div className="floating-element-2 absolute bottom-40 left-20 w-16 h-16 bg-gradient-to-br from-[#D4BFFC]/42 to-transparent rounded-full blur-sm opacity-75" style={{ animationDelay: '2s' }}></div>
        <div className="floating-element-3 absolute top-60 left-60 w-12 h-12 bg-gradient-to-br from-[#9667E0]/47 to-transparent rounded-full blur-sm opacity-85" style={{ animationDelay: '0.5s' }}></div>
      </div>

      {/* Pattern overlays */}
      <div
        className="absolute inset-0 opacity-15 pointer-events-none z-0"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, rgba(150, 103, 224, 0.2) 1px, transparent 0)`,
          backgroundSize: "20px 20px",
        }}
      ></div>

      <div
        className="absolute inset-0 opacity-8 pointer-events-none z-0"
        style={{
          backgroundImage: `linear-gradient(45deg, transparent 40%, rgba(150, 103, 224, 0.08) 50%, transparent 60%), linear-gradient(-45deg, transparent 40%, rgba(212, 191, 252, 0.08) 50%, transparent 60%)`,
          backgroundSize: "60px 60px",
        }}
      ></div>

      {/* Main content */}
      <div className="flex gap-4 h-[calc(100vh-2rem)] relative z-10">
        <NavigationSidebar />
        <MainDashboard />
      </div>
    </div>
  )
}
