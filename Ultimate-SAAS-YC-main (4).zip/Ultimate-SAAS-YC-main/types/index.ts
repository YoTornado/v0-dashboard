export enum MessageSource {
  USER = "You",
  GEMINI = "Tutor",
  SYSTEM = "System",
}

export interface ChatMessage {
  id: string
  source: MessageSource
  text: string
  timestamp: string
}

export type ConnectionStatus = "disconnected" | "connecting" | "connected" | "error"
