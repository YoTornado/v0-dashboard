"use client"

import type React from "react"

import { useState, useRef, useCallback, useEffect } from "react"
import { type ChatMessage, MessageSource, type ConnectionStatus } from "../types"

const WEBSOCKET_URL = "ws://localhost:9083"

export const useTutorSession = (videoElementRef: React.RefObject<HTMLVideoElement>) => {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [isSessionActive, setIsSessionActive] = useState(false)
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>("disconnected")

  // Refs for various browser and media objects
  const webSocketRef = useRef<WebSocket | null>(null)
  const mediaStreamRef = useRef<MediaStream | null>(null)
  const audioInputContextRef = useRef<AudioContext | null>(null)
  const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null)
  const audioPlaybackContextRef = useRef<AudioContext | null>(null)
  const audioWorkletNodeRef = useRef<AudioWorkletNode | null>(null)

  // Refs for managing data and intervals
  const pcmDataRef = useRef<number[]>([])
  const currentFrameB64Ref = useRef<string | null>(null)
  const captureIntervalRef = useRef<NodeJS.Timeout | null>(null)

  const addMessage = useCallback((text: string, source: MessageSource) => {
    setMessages((prev) => [
      ...prev,
      {
        id: crypto.randomUUID(),
        source,
        text,
        timestamp: new Date().toLocaleTimeString(),
      },
    ])
  }, [])

  const setupPlaybackAudio = useCallback(async () => {
    if (audioPlaybackContextRef.current) return
    try {
      const context = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 })
      audioPlaybackContextRef.current = context

      // Inline the worklet code to avoid fetch errors
      const pcmProcessorCode = `
class PCMProcessor extends AudioWorkletProcessor {
    constructor() {
        super();
        this.buffer = new Float32Array();
        this.port.onmessage = (e) => {
            const newData = e.data;
            if (newData instanceof Float32Array) {
                const newBuffer = new Float32Array(this.buffer.length + newData.length);
                newBuffer.set(this.buffer);
                newBuffer.set(newData, this.buffer.length);
                this.buffer = newBuffer;
            }
        };
    }

    process(inputs, outputs, parameters) {
        const output = outputs[0];
        const channelData = output[0];

        if (this.buffer.length >= channelData.length) {
            channelData.set(this.buffer.slice(0, channelData.length));
            this.buffer = this.buffer.slice(channelData.length);
        } else {
            channelData.set(this.buffer);
            this.buffer = new Float32Array();
        }
        return true;
    }
}
registerProcessor('pcm-processor', PCMProcessor);
        `
      const blob = new Blob([pcmProcessorCode.trim()], { type: "application/javascript" })
      const workletURL = URL.createObjectURL(blob)

      await context.audioWorklet.addModule(workletURL)
      URL.revokeObjectURL(workletURL) // Clean up the object URL

      const workletNode = new AudioWorkletNode(context, "pcm-processor")
      workletNode.connect(context.destination)
      audioWorkletNodeRef.current = workletNode
    } catch (error) {
      console.error("Error setting up playback audio: ", error)
      addMessage(`Failed to initialize audio playback: ${(error as Error).message}`, MessageSource.SYSTEM)
    }
  }, [addMessage])

  const playAudioChunk = useCallback(async (base64AudioChunk: string) => {
    if (!audioPlaybackContextRef.current || !audioWorkletNodeRef.current) {
      console.error("Audio playback not initialized.")
      return
    }
    try {
      if (audioPlaybackContextRef.current.state === "suspended") {
        await audioPlaybackContextRef.current.resume()
      }
      const binaryString = window.atob(base64AudioChunk)
      const bytes = new Uint8Array(binaryString.length)
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i)
      }
      const pcm16Data = new Int16Array(bytes.buffer)
      const float32Data = new Float32Array(pcm16Data.length)
      for (let i = 0; i < pcm16Data.length; i++) {
        float32Data[i] = pcm16Data[i] / 32768
      }
      audioWorkletNodeRef.current.port.postMessage(float32Data)
    } catch (error) {
      console.error("Error processing audio chunk:", error)
    }
  }, [])

  const handleWebSocketMessage = useCallback(
    (event: MessageEvent) => {
      try {
        const messageData = JSON.parse(event.data)
        if (messageData.text) {
          addMessage(messageData.text, MessageSource.GEMINI)
        }
        if (messageData.audio) {
          playAudioChunk(messageData.audio)
        }
      } catch (error) {
        console.error("Error parsing WebSocket message:", error)
      }
    },
    [addMessage, playAudioChunk],
  )

  const connectWebSocket = useCallback(() => {
    if (webSocketRef.current) return

    setConnectionStatus("connecting")
    const ws = new WebSocket(WEBSOCKET_URL)

    ws.onopen = () => {
      console.log("WebSocket connected")
      setConnectionStatus("connected")
      const setupMessage = {
        setup: {
          generation_config: { response_modalities: ["AUDIO"] },
        },
      }
      ws.send(JSON.stringify(setupMessage))
    }

    ws.onmessage = handleWebSocketMessage

    ws.onclose = () => {
      console.log("WebSocket disconnected")
      setConnectionStatus("disconnected")
      if (isSessionActive) {
        addMessage("Connection to server lost. Please restart the session.", MessageSource.SYSTEM)
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        stopSession()
      }
    }

    ws.onerror = (error) => {
      console.error("WebSocket error:", error)
      setConnectionStatus("error")
      addMessage(
        `Connection Error: Could not connect to the server at ${WEBSOCKET_URL}. Please ensure the backend server is running and accessible.`,
        MessageSource.SYSTEM,
      )
    }

    webSocketRef.current = ws
  }, [handleWebSocketMessage, addMessage, isSessionActive])

  const captureAndSend = useCallback(() => {
    const video = videoElementRef.current
    if (video && video.readyState >= 2) {
      const canvas = document.createElement("canvas")
      canvas.width = 640
      canvas.height = 480
      const context = canvas.getContext("2d")
      if (context) {
        context.drawImage(video, 0, 0, canvas.width, canvas.height)
        currentFrameB64Ref.current = canvas.toDataURL("image/jpeg").split(",")[1].trim()
      }
    }

    if (pcmDataRef.current.length > 0) {
      const buffer = new ArrayBuffer(pcmDataRef.current.length * 2)
      const view = new DataView(buffer)
      pcmDataRef.current.forEach((value, index) => {
        view.setInt16(index * 2, value, true)
      })
      const audioB64 = btoa(String.fromCharCode.apply(null, new Uint8Array(buffer)))
      pcmDataRef.current = []

      if (webSocketRef.current?.readyState === WebSocket.OPEN) {
        // Send audio chunk
        const audioPayload = {
          realtime_input: {
            media_chunks: [{ mime_type: "audio/pcm", data: audioB64 }],
          },
        }
        webSocketRef.current.send(JSON.stringify(audioPayload))

        // Send image chunk separately if available
        if (currentFrameB64Ref.current) {
          const imagePayload = {
            realtime_input: {
              media_chunks: [{ mime_type: "image/jpeg", data: currentFrameB64Ref.current }],
            },
          }
          webSocketRef.current.send(JSON.stringify(imagePayload))
        }
      }
    }
  }, [videoElementRef])

  const startSession = useCallback(async () => {
    addMessage("Starting session...", MessageSource.SYSTEM)
    setIsSessionActive(true)

    try {
      // 1. Get media streams
      const screenStream = await navigator.mediaDevices.getDisplayMedia({
        video: { width: 640, height: 480 },
        audio: false, // We'll capture mic separately for more control
      })

      const micStream = await navigator.mediaDevices.getUserMedia({
        audio: { channelCount: 1, sampleRate: 16000 },
      })

      mediaStreamRef.current = screenStream
      if (videoElementRef.current) {
        videoElementRef.current.srcObject = screenStream
      }

      // 2. Setup audio capture
      const audioContext = new AudioContext({ sampleRate: 16000 })
      audioInputContextRef.current = audioContext
      const source = audioContext.createMediaStreamSource(micStream)
      const processor = audioContext.createScriptProcessor(4096, 1, 1)

      processor.onaudioprocess = (e) => {
        const inputData = e.inputBuffer.getChannelData(0)
        const pcm16 = new Int16Array(inputData.length)
        for (let i = 0; i < inputData.length; i++) {
          pcm16[i] = inputData[i] * 0x7fff
        }
        pcmDataRef.current.push(...pcm16)
      }

      source.connect(processor)
      processor.connect(audioContext.destination) // Connect to destination to start processing
      scriptProcessorRef.current = processor

      // 3. Setup audio playback and WebSocket
      await setupPlaybackAudio()
      connectWebSocket()

      // 4. Start data capture interval
      captureIntervalRef.current = setInterval(captureAndSend, 3000)
    } catch (error) {
      console.error("Failed to start session:", error)
      addMessage(`Error starting session: ${(error as Error).message}`, MessageSource.SYSTEM)
      setIsSessionActive(false)
    }
  }, [addMessage, videoElementRef, setupPlaybackAudio, connectWebSocket, captureAndSend])

  const stopSession = useCallback(() => {
    addMessage("Session ended.", MessageSource.SYSTEM)
    setIsSessionActive(false)
    setConnectionStatus("disconnected")

    // Clear intervals
    if (captureIntervalRef.current) {
      clearInterval(captureIntervalRef.current)
      captureIntervalRef.current = null
    }

    // Close WebSocket
    if (webSocketRef.current) {
      webSocketRef.current.close()
      webSocketRef.current = null
    }

    // Stop media tracks
    mediaStreamRef.current?.getTracks().forEach((track) => track.stop())
    mediaStreamRef.current = null
    if (videoElementRef.current) {
      videoElementRef.current.srcObject = null
    }

    // Disconnect and close audio contexts
    scriptProcessorRef.current?.disconnect()
    scriptProcessorRef.current = null
    audioInputContextRef.current?.close()
    audioInputContextRef.current = null
    audioPlaybackContextRef.current?.close()
    audioPlaybackContextRef.current = null

    // Clear data buffers
    pcmDataRef.current = []
    currentFrameB64Ref.current = null
  }, [addMessage, videoElementRef])

  useEffect(() => {
    // Cleanup on unmount
    return () => {
      if (isSessionActive) {
        stopSession()
      }
    }
  }, [isSessionActive, stopSession])

  return { messages, isSessionActive, connectionStatus, startSession, stopSession }
}
